package com.zu_libraries_automation.fayed.zag_uni_lib_automation;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Favourits extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourits);
    }
}
