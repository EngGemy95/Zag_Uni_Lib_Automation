package com.zu_libraries_automation.fayed.zag_uni_lib_automation;

/**
 * Created by USER on 12/23/2016.
 */
public class Faculties {
    String facultyName;
    int facultyIcon;

    public String getFacultyName() {
        return facultyName;
    }

    public void setFacultyName(String facultyName) {
        this.facultyName = facultyName;
    }

    public int getFacultyIcon() {
        return facultyIcon;
    }

    public void setFacultyIcon(int facultyIcon) {
        this.facultyIcon = facultyIcon;
    }
}